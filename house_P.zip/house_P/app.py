from flask import Flask, request, jsonify, render_template
import pandas as pd
from joblib import load

# Load model and scaler (same trained model)
try:
    model = load("saved_model/linear_regression_model.pkl")
    scaler = load("saved_model/scaler.pkl")
    print("Model and Scaler loaded successfully.")
except FileNotFoundError:
    print("FATAL ERROR: Model or Scaler not found. Run model.py first.")
    exit()

app = Flask(__name__)

FEATURE_NAMES = [
    "MedInc", "HouseAge", "AveRooms", "AveBedrms",
    "Population", "AveOccup", "Latitude", "Longitude"
]

# Mapping Indian regions to approximate lat/long
REGION_MAPPING = {
    "North": (28.6, 77.2),      # Delhi
    "West": (19.1, 72.8),       # Mumbai
    "South": (13.0, 77.6),      # Bangalore
    "East": (22.6, 88.4),       # Kolkata
    "Central": (23.2, 77.4)     # Bhopal
}

# Default values
DEFAULTS = {
    "AveBedrms": 1.1,
    "Population": 1500,
    "AveOccup": 3.0
}

# ------------------------------
@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        try:
            # User input in lakhs INR
            MedInc = float(request.form["MedInc"]) / 100000  # convert INR to 100k units
            HouseAge = float(request.form["HouseAge"])
            AveRooms = float(request.form["AveRooms"])
            region = request.form["Region"]

            Latitude, Longitude = REGION_MAPPING.get(region, (23.2, 77.4))

            input_df = pd.DataFrame([[
                MedInc, HouseAge, AveRooms,
                DEFAULTS["AveBedrms"], DEFAULTS["Population"], DEFAULTS["AveOccup"],
                Latitude, Longitude
            ]], columns=FEATURE_NAMES)

            scaled_input = scaler.transform(input_df)
            prediction = model.predict(scaled_input)[0]

            # Convert to INR
            predicted_inr = prediction * 100000  # model predicts in 100k units
            result = f"Predicted House Value: ₹{predicted_inr:,.0f}"

            return render_template("index.html", prediction_text=result)

        except Exception as e:
            return render_template("index.html", prediction_text=f"Error: {e}")

    return render_template("index.html", prediction_text="Enter details to predict house price")


# ------------------------------
@app.route("/predict_api", methods=["POST"])
def predict_api():
    try:
        data = request.get_json(force=True)
        MedInc = float(data["MedInc"]) / 100000  # INR to 100k units
        HouseAge = float(data["HouseAge"])
        AveRooms = float(data["AveRooms"])
        region = data.get("Region", "Central")

        Latitude, Longitude = REGION_MAPPING.get(region, (23.2, 77.4))

        input_df = pd.DataFrame([[
            MedInc, HouseAge, AveRooms,
            DEFAULTS["AveBedrms"], DEFAULTS["Population"], DEFAULTS["AveOccup"],
            Latitude, Longitude
        ]], columns=FEATURE_NAMES)

        scaled_input = scaler.transform(input_df)
        prediction = model.predict(scaled_input)[0]

        predicted_inr = prediction * 100000
        return jsonify({"Predicted_House_Value_INR": round(float(predicted_inr), 0)})

    except Exception as e:
        return jsonify({"error": str(e)}), 400


# ------------------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
