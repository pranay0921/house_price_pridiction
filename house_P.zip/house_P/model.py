# ============================================================
# model.py — Train & Save Indian Housing ML Model (Mock Data)
# ============================================================

import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from joblib import dump

# ============================================================
# 1. CREATE MOCK INDIAN HOUSING DATA
# ============================================================
print("📥 Creating mock Indian housing dataset...")

np.random.seed(42)
n_samples = 1000

# Features
MedInc = np.random.uniform(2, 50, n_samples)          # in lakhs INR
HouseAge = np.random.randint(1, 50, n_samples)       # years
AveRooms = np.random.uniform(2, 10, n_samples)       # avg rooms
AveBedrms = np.random.uniform(1, 3, n_samples)       # avg bedrooms
Population = np.random.randint(500, 5000, n_samples)
AveOccup = np.random.uniform(2, 6, n_samples)

# Latitude/Longitude for Indian regions
regions = {
    "North": (28.6, 77.2),      # Delhi
    "West": (19.1, 72.8),       # Mumbai
    "South": (13.0, 77.6),      # Bangalore
    "East": (22.6, 88.4),       # Kolkata
    "Central": (23.2, 77.4)     # Bhopal
}
region_keys = list(regions.keys())
region_choice = np.random.choice(region_keys, n_samples)

Latitude = np.array([regions[r][0] for r in region_choice])
Longitude = np.array([regions[r][1] for r in region_choice])

# Target: House Price (INR)
# Use a simple formula with some noise
HousePrice = (
    MedInc * 0.5 + AveRooms * 0.3 + HouseAge * 0.2 +
    np.random.normal(0, 5, n_samples)
) * 10000     # Convert to INR

# Build DataFrame
df = pd.DataFrame({
    "MedInc": MedInc,
    "HouseAge": HouseAge,
    "AveRooms": AveRooms,
    "AveBedrms": AveBedrms,
    "Population": Population,
    "AveOccup": AveOccup,
    "Latitude": Latitude,
    "Longitude": Longitude,
    "HousePrice": HousePrice
})

print("✅ Mock dataset created!\n")

# ============================================================
# 2. TRAIN-TEST SPLIT
# ============================================================
X = df.drop(columns=["HousePrice"])
y = df["HousePrice"]

print("🔀 Splitting dataset into train/test sets...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"Training samples: {X_train.shape[0]}, Test samples: {X_test.shape[0]}\n")

# ============================================================
# 3. FEATURE SCALING
# ============================================================
print("📊 Scaling features...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("✅ Scaling completed!\n")

# ============================================================
# 4. MODEL TRAINING
# ============================================================
print("🛠 Training Linear Regression model...")
model = LinearRegression()
model.fit(X_train_scaled, y_train)
print("✅ Model training completed!\n")

# ============================================================
# 5. MODEL EVALUATION
# ============================================================
print("📈 Evaluating model...")
y_pred = model.predict(X_test_scaled)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"📊 Model Performance:")
print(f"  - Mean Squared Error (MSE): {mse:.2f}")
print(f"  - R-squared (R2): {r2:.3f}\n")

# ============================================================
# 6. SAVE MODEL & SCALER
# ============================================================
print("💾 Saving model and scaler to 'saved_model/'...")
os.makedirs("saved_model", exist_ok=True)
dump(model, "saved_model/linear_regression_model.pkl")
dump(scaler, "saved_model/scaler.pkl")
print("✅ Model and scaler saved successfully!")
print("🎉 India Housing ML pipeline completed!")
